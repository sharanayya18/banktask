const checkToken = () => {

    const token = localStorage.getItem('isAuthenticated');
    return token;

    
}

export default checkToken;
