import axios from "axios";
import React, { useEffect, useRef, useState } from "react";
import { Button, Card, FloatingLabel, Form } from "react-bootstrap";
import { FaEnvelope, FaLock } from "react-icons/fa";
// import { BsFillPersonFill ,BsFillPersonPlusFill} from "react-icons/bs";
import { useHistory } from "react-router-dom";
import Navigationbar from "./Navigationbar";

const Loginpage = () => {
  const email = useRef();
  const password = useRef();
  const history = useHistory();

  const [error, setError] = useState("");
  const [loginuser, setloginuser] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    let copy = { ...loginuser, [name]: value };
    setloginuser(copy);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError(validate(loginuser));
    // console.log(loginuser, "=============login");
    login();
  };

  const validate = (values) => {
    let err = {};

    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;

    if (!values.email) {
      err.email = "Email is required!";
    } else if (!regex.test(values.email)) {
      err.email = "This is not a valid email format!";
    }
    if (!values.password) {
      err.password = "Password is required";
    } else if (values.password.length < 4) {
      err.password = "Password must be more than 4 characters";
    } else if (values.password.length > 10) {
      err.password = "Password cannot exceed more than 10 characters";
    }
    return err;
  };

  // console.log('in login page ');


  const login = async () => {
    const { email, password } = loginuser;

    try {

      const data = await axios.post("/login", { email, password });
      console.log("data>>", data);
      const role = data.data.role;
      const token = data.data.token;
      if (role) { localStorage.setItem("role", role) }
      if (token) { localStorage.setItem("name", data.data.user) }
      if (token) { localStorage.setItem("isAuthenticated", token) }
      if (data.data.error) {
        console.log(data.data.message);
        // alert(data.data.message);
      } else {
        alert(data.data.message);
        history.push("/Samples");
      }
    } catch (err) {
      console.log(err);
    }
  };


  console.log(error);

  useEffect(() => {
    // login();
  }, []);

  return (
    <div>
      <Navigationbar />

      <Card className="formcard p-5">
        <Form method="POST">
          <h4>Login Here!</h4>

          <Card.Body>

            <FloatingLabel label={<FaEnvelope />} className="mt-5 mb-4" >
              <Form.Control className="inputtag" onChange={handleChange} name="email" type="email" placeholder="enter email" ref={email} />
              <span style={{ color: "red" }}>{error.email}</span>
            </FloatingLabel>

            <FloatingLabel label={<FaLock />} className="mb-4" >
              <Form.Control className="inputtag" name="password" onChange={handleChange} type="password" placeholder="enter password" ref={password} />
              <span style={{ color: "red" }}>{error.password}</span>
            </FloatingLabel>

            <div className="d-flex justify-content-center">
              <Button variant="outline-success" onClick={handleSubmit} className="mt-3" > {" "} Sign Up{" "} </Button>
            </div>

          </Card.Body>
        </Form>
      </Card>
    </div>
  );
};

export default Loginpage;
