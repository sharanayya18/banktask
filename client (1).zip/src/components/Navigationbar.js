// import { Button } from 'bootstrap'
import React from "react";
import checkToken from '../checkAuth/checkAuth'
import { Container, Nav, Navbar } from "react-bootstrap";
import { NavLink } from "react-router-dom";
import { useHistory } from "react-router-dom";


const Navigationbar = () => {

  // var cookiesMap = document.cookie
  // console.log(cookiesMap, "--------------navcookie")

  const history = useHistory();

  const token = checkToken();
  const role = localStorage.getItem("role");



  const logout = () => {
    localStorage.clear();
    history.push('/')
  }


  return (
    <div>
      <Navbar bg="light" expand="lg">
        <Container>
          <Navbar.Brand to="/Samples" className="navtags">
            Laboratory
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="navbarScroll" />
          <Navbar.Collapse id="navbarScroll">

            {token &&
              <Nav className="me-auto my-2 my-lg-0" navbarScroll>
                <NavLink to="/Samples" className="navtags">{role === "admin" ? "Sample" : "Dashboard"}</NavLink>
                <NavLink to="/EnterSample" className="navtags">{role === "admin" ? "EnterSample" : " "}</NavLink>
              </Nav>
            }

            <Nav className="d-flex">
              {role === "admin" ? <NavLink to="/RegistrationPage" className="navtags">Register</NavLink> : ""}
              {!token ? <NavLink to="/" className="navtags">login</NavLink> : <NavLink to="/" className="navtags" onClick={logout}>Logout</NavLink>}

            </Nav>


          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  );
};

export default Navigationbar;
