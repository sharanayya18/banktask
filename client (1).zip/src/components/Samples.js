import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Button, FormControl, Table } from 'react-bootstrap'
import GlucometryForm from './glucometry/GlucometryForm'
import GlucometryReport from './glucometry/GlucometryReport'
import GlucometryUpdate from './glucometry/GlucometryUpdate'
import Haematology from './haematology/Haematology'
import HaematologyReport from './haematology/HaematologyReport'
import HaematologyUpdate from './haematology/haematologyUpdate'
import Navigationbar from './Navigationbar'
import Thyroidform from './thyroid/Thyroidform'
import ThyroidReport from './thyroid/ThyroidReport'
import ThyroidUpdate from './thyroid/ThyroidUpdate'
import EditUser from './updateUser/EditUser'

const Samples = () => {

  const role = localStorage.getItem('role');

  // table data
  const [samples, setsamples] = useState([])

  const [matchdata, setmatchdata] = useState([])

  const [showSearch, setshowSearch] = useState(false)


  const search = (e) => {
    console.log(e.target.value);
    var searchinput = e.target.value



    const Match = samples.filter((mch, inx, arr) => {
      // console.log(mch);0
      console.log(mch.name.toLowerCase());
      return mch.name.toLowerCase().startsWith(searchinput.toLowerCase());
    })

    console.log(Match, "--------match");
    setmatchdata(Match);


    if (Match.length > 0) {
      setshowSearch(true);
    } else {
      setshowSearch(false);
    }

  }

  // --------------------  ADD UPDATE REPORTS  -----------------------//

  // ================== Haematology model ==================//

  const [haemForm, sethaemForm] = useState(false);
  const [haemid, sethaemid] = useState();

  const [haemReport, sethaemReport] = useState(false);
  const [hemoData, sethemoData] = useState();

  const [hemoUpdateid, sethemoUpdateid] = useState();
  const [hemoUpdateform, sethemoUpdateform] = useState(false);



  // ===================  Thyroid model===================   //

  const [thyroidForm, setThyroidForm] = useState(false);
  const [thyrid, setthyrid] = useState();


  const [thyroidReport, setThyroidReport] = useState(false);
  const [thyrData, setthyrData] = useState();

  const [thyrUpdateid, setthyrUpdateid] = useState();
  const [thyrUpdateform, setthyrUpdateform] = useState(false);



  // ===================== Glucometry model ===================== //

  const [GlucomForm, setGlucomForm] = useState(false);
  const [Glucid, setGlucid] = useState();


  const [GlucomReport, setGlucomReport] = useState(false);
  const [glucData, setglucData] = useState();


  const [glycUpdateid, setglycUpdateid] = useState();
  const [glycoUpdateform, setglycoUpdateform] = useState(false);


  useEffect(() => {
    getdata();
  }, [])


  const getdata = async () => {
    console.log('in sample')

    try {
      const data = await axios.get(`/sample`)
      console.log(data.data);
      setsamples(data.data)
    } catch (err) {
      console.log(err);
    }
  }


  const HaemaModel = (id) => {
    sethaemid(id)
    sethaemForm(true)
  }

  const HemoatologyReport = (data, id) => {
    console.log(data, id, "-----------------HemoatologyReport");
    sethemoData(data)
    sethemoUpdateid(id)
    sethaemReport(true);
  }


  const ThyroidModal = (id) => {
    setthyrid(id)
    setThyroidForm(true)
  }

  const ThyroidReports = (data, id) => {
    console.log(data, "-----------------ThyroidReports");
    setthyrData(data);
    setthyrUpdateid(id)
    setThyroidReport(true);
  }

  //====================== Glucomertry  ======================// 

  const GlucometryModal = (id) => {
    setGlucid(id)
    setGlucomForm(true)
  }

  const GlucometryReports = (data, id) => {
    console.log(data, id, "-----------------GlucometryReports");
    setglucData(data)
    setglycUpdateid(id)
    setGlucomReport(true)
  }

  //====================== UPDATE MODALS OPEN  ======================// 


  const [updateUser, setupdateUser] = useState(false);
  const [editUserData, seteditUserData] = useState()

  const reload = () => {
    getdata();
  }

  const editUser = async (userdata) => {
    setupdateUser(true);
    seteditUserData(userdata);
  }

  const removeUser = async (id) => {
    try {
      console.log(id)
      const res = await axios.post('http://localhost:4400/removeUser', { id });
      console.log(res, "--------------remove data");
      if (!res.data.error) {
        reload();
      }

    } catch (err) {
      console.log(err);
    }

  };

  const user = localStorage.getItem('name');
  console.log(user)
  return (
    <>
      <Navigationbar />

      <div className='cd'>


        <h4>Welcome <em>{user}</em> </h4>
        <br />
        <div className='d-flex justify-content-center'>
          <FormControl type="search" placeholder="Search" className="me-2 search" aria-label="Search" onChange={(e) => search(e)} />
        </div>

        <Table hover className='tablecard p-0' variant="" responsive >

          <thead>

            <tr>
              <th className='th'>Sample Date</th>
              <th className='th'>Patient Name</th>
              <th className='th'>Email</th>
              <th className='th'>Sample ID</th>
              <th className='th'>haemaology </th>
              <th className='th'>Thyroid_Profile </th>
              <th className='th'>Glucometry  </th>
              {role !== "user" && <th className='th'>Edit </th>}
              {role !== "user" && <th className='th'>Delete </th>}
            </tr>
          </thead>

          <tbody>

            {!showSearch && samples.map((val, inx) => {
              return (
                <tr key={inx}>
                  <td>{val.date ? val.date : val._id}</td>
                  <td>{val.name}</td>
                  <td>{val.email}</td>
                  <td>{inx + 101}</td>
                  <td>{!val.test ? <Button variant='info' >No-Test</Button> : val.status.hemo ? (val.heamatology.length > 0 ? <Button variant='success' onClick={() => { HemoatologyReport(val.heamatology, val._id) }}> view_report </Button> : <Button variant='primary' onClick={() => { HaemaModel(val._id) }} >add_Details</Button>) : <Button variant='light'>N/A</Button>}</td>
                  <td>{!val.test ? <Button variant='info' >No-Test</Button> : val.status.thyr ? (val.thyroid.length > 0 ? <Button variant='success' onClick={() => { ThyroidReports(val.thyroid, val._id) }} >view_report</Button> : <Button variant='primary' onClick={() => { ThyroidModal(val._id) }}>add Details</Button>) : <Button variant='light'>N/A</Button>}</td>
                  <td>{!val.test ? <Button variant='info' >No-Test</Button> : val.status.glu ? (val.glucometry.length > 0 ? <Button variant='success' onClick={() => { GlucometryReports(val.glucometry, val._id) }}>View_Reports</Button> : <Button variant='primary' onClick={() => { GlucometryModal(val._id) }}>add_Details</Button>) : <Button variant='light'>N/A</Button>}</td>
                  {role !== "user" && <td> <Button variant='light' onClick={() => { editUser(val) }}>Edit</Button>  </td>}
                  {role !== "user" && <td> <Button variant='danger' onClick={() => { removeUser(val._id) }}  >remove_{val.name}</Button>  </td>}
                </tr>
              )
            })}

            {showSearch && matchdata.map((val, inx) => {
              return (
                <tr key={inx}>
                  <td>{val.date ? val.date : val._id}</td>
                  <td>{val.name}</td>
                  <td>{val.email}</td>
                  <td>{inx + 101}</td>
                  <td>{!val.test ? <Button variant='info'>No-Test</Button> : val.status.hemo ? (val.heamatology.length > 0 ? <Button variant='success' onClick={() => { HemoatologyReport(val.heamatology, val._id) }}> view_report </Button> : <Button variant='primary' onClick={() => { HaemaModel(val._id) }} >add_Details</Button>) : <Button variant='light'>N/A</Button>}</td>
                  <td>{!val.test ? <Button variant='info'>No-Test</Button> : val.status.thyr ? (val.thyroid.length > 0 ? <Button variant='success' onClick={() => { ThyroidReports(val.thyroid, val._id) }} >view_report</Button> : <Button variant='primary' onClick={() => { ThyroidModal(val._id) }}>add_Details</Button>) : <Button variant='light'>N/A</Button>}</td>
                  <td>{!val.test ? <Button variant='info'>No-Test</Button> : val.status.glu ? (val.glucometry.length > 0 ? <Button variant='success' onClick={() => { GlucometryReports(val.glucometry, val._id) }}>View_Reports</Button> : <Button variant='primary' onClick={() => { GlucometryModal(val._id) }}>add_Details</Button>) : <Button variant='light'>N/A</Button>}</td>
                  {role !== "user" && <td> <Button variant='light' onClick={() => { editUser(val) }}>Edit</Button>  </td>}
                  {role !== "user" && <td> <Button variant='danger' onClick={() => { removeUser(val._id) }}  >remove_{val.name}</Button>  </td>}
                </tr>
              )
            })}

          </tbody>

        </Table>



        <Haematology reload={reload} haemForm={haemForm} sethaemForm={sethaemForm} id={haemid && haemid} />
        <Thyroidform reload={reload} thyroidForm={thyroidForm} setThyroidForm={setThyroidForm} id={thyrid} />
        <GlucometryForm reload={reload} GlucomForm={GlucomForm} setGlucomForm={setGlucomForm} id={Glucid} />



        <HaematologyUpdate reload={reload} sethemoUpdateform={sethemoUpdateform} hemoUpdateform={hemoUpdateform} id={hemoUpdateid && hemoUpdateid} hemoData={hemoData && hemoData} />
        <ThyroidUpdate reload={reload} setthyrUpdateform={setthyrUpdateform} thyrUpdateform={thyrUpdateform} id={thyrUpdateid && thyrUpdateid} thyrData={thyrData && thyrData} />
        <GlucometryUpdate reload={reload} setglycoUpdateform={setglycoUpdateform} glycoUpdateform={glycoUpdateform} id={glycUpdateid && glycUpdateid} glucData={glucData && glucData} />



        <HaematologyReport haemReport={haemReport} sethaemReport={sethaemReport} hemoData={hemoData && hemoData} sethaemForm={sethaemForm} sethemoUpdateform={sethemoUpdateform} />
        <ThyroidReport thyroidReport={thyroidReport} setThyroidReport={setThyroidReport} thyrData={thyrData && thyrData} setThyroidForm={setThyroidForm} setthyrUpdateform={setthyrUpdateform} />
        <GlucometryReport GlucomReport={GlucomReport} setGlucomReport={setGlucomReport} glucData={glucData && glucData} setGlucomForm={setGlucomForm} setglycoUpdateform={setglycoUpdateform} />



        <EditUser setupdateUser={setupdateUser} updateUser={updateUser} editUserData={editUserData && editUserData} />



      </div>

    </>
  )
}

export default Samples
