import axios from 'axios'
import React, { useEffect, useRef, useState } from 'react'
import { Button, Col, FloatingLabel, Form, Modal, Row } from 'react-bootstrap'
import { useHistory } from 'react-router-dom'
import Navigationbar from './Navigationbar'




const EnterSample = () => {


  const history = useHistory();


  const [samples, setsamples] = useState([])

  const [sendDate, setsendDate] = useState({})

  const [hemo, setHemo] = useState(false)
  const [thyr, setThyr] = useState(false)
  const [glu, setglu] = useState(false)


  useEffect(() => {
    getdata();
  }, [])



  const getdata = async () => {
    // console.log(samples);
    try {
      const res = await fetch('/Entersample', {
        method: "GET",
        headers: {
          "Content-Type": "application/json"
        },
      })
      const data = await res.json()
      console.log(data);
      setsamples(data)
    } catch (err) {
      console.log(err);
    }
  }

  const user = useRef()
  const date = useRef()

  const radio = (e) => {
    const val = e.target.value
    const id = e.target.id
    console.log(val, id);
    id === "1" ? setHemo(true) : id === "2" ? setThyr(true) : setglu(true)
  }

  const CollectData = async () => {
    console.log(date.current.value, "-------------date")

    await setsendDate({
      user: user.current.value,
      hemo: hemo,
      thyr: thyr,
      glu: glu,
      date: date.current.value
    })


    postDate();
  }


  // useEffect(() => {
  //   CollectData()
  //   postDate();
  // }, [])


  const postDate = async () => {


    const { user, hemo, thyr, glu, date } = sendDate
    console.log(user, hemo, thyr, glu, date, "-----------------date");


    if (!user || !hemo || !thyr || !glu || !date) {
      console.log(user, hemo, thyr, glu, date, "----------------- create sample data");

      try {
        console.log("=======in side postDate")
        const send = await axios.post('/Entersample', { user, hemo, thyr, glu, date })
        console.log(send.data.massege, "------------entersample");
        if (send.data) {
          // history.push('/Samples')
        } else {
          history.push('/EnterSample')
        }
      } catch (err) {
        console.log(err)
      }

    } else {
      alert('fill all details...!');



    }


  }


  return (
    <>
      <Navigationbar />

      <Modal.Dialog>
        <Modal.Header >
          <Modal.Title>Creat Test </Modal.Title>
        </Modal.Header>
        <div className='container mt-3'>
          <FloatingLabel controlId="floatingSelect" label=" selects Patient" className="mb-4" >
            <Form.Select aria-label="Floating label select example" ref={user} >
              {samples.map((val, inx) => {
                return <option value={val._id} key={inx}>{val.name}</option>
              })}
            </Form.Select>
          </FloatingLabel>
        </div>




        <Modal.Body>


          <Row>
            <Col>

              <Form.Check type="checkbox" name="radio 1" id='1' label="Haemotology" onChange={radio} />
              <br />
              <Form.Check type="checkbox" name="radio 1" id='2' label=" Thyroid Profile" onChange={radio} />
              <br />
              <Form.Check type="checkbox" name="radio 1" id='3' label="Glucometry" onChange={radio} />


            </Col>

            <Col>

              <FloatingLabel controlId="floatingInput" label="Email address" className="mb-3" >
                <Form.Control type="date" placeholder="name@example.com" ref={date} />
              </FloatingLabel>


            </Col>

          </Row>




        </Modal.Body>

        <Modal.Footer>
          <Button variant="primary" onClick={CollectData}>Submit</Button>
        </Modal.Footer>

      </Modal.Dialog>


    </>
  )
}

export default EnterSample