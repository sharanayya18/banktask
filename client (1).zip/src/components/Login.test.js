import Loginpage from './Loginpage';
import {fireEvent,render} from '@testing-library/react';

describe {"Login button",()=>{
    it("login button render",()={
        let{queryByTitle)=render(<SignUp/>)}
    })

}}

