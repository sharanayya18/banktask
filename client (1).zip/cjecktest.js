const arr = [{ sdf: 123 }];
const bro = [];

if (arr.length >= 1) {
    console.log(true, arr);
} else {
    console.log(false, bro);
}