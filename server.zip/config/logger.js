const { transports } = require("winston");
const winston = require("winston/lib/winston/config");

const { createLogger, trasports, formate } = winston;

const logger = createLogger({

    //   3 methose >>>console, file, mongoDB
    transports: [
        new transports.console({
            level: "info",
            format: formate.combine(trasports);
        }),


        new transports.File({
            filename: "data.log",
            level: 'error',
            fomate: formate.combine(formate)
        }),


        new transports.File({
            fileName: "data1.log",
            level: 'warn',
            // formate: formate.combine(formate)
        })





    ]
}
)










