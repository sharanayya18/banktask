const express = require('express')
const app = express();
const port = 4400;
const cookieparser = require('cookie-parser')
const cors = require('cors');
// const logger = require('./config/logger')

app.use(cors());

const Authenticate = require('./middleware/Authenticate');

//    import database connection part
require("./db/conn");

app.use(express.json());

app.use(cookieparser());

const database = require('./model/dataSchema');

app.post('/', function (req, res) {
    res.send(req.body)
});


app.post('/login', async (req, res) => {
    console.log('login', req.body);
    const { email, password } = req.body

    if (!email || !password) {
        res.json({
            error: true,
            message: "fill again   ...!",
            data: null
        })
    } else {

        try {
            const data = await database.findOne({ email: email, password: password });
            const token = await data.ganerateToken();

            // console.log('TOKEN===>>',token);
            res.cookie(`brotokens`, token)
            if (!data) {
                res.json({
                    error: true,
                    message: "login failed...!",
                    data: null
                })
            } else {
                res.cookie("brotokens", token)
                res.json({
                    error: false,
                    message: "login succesfull...!",
                    role: data.role,
                    user: data.name,
                    token: token
                })

            }

        } catch (err) {
            console.log('err');
            res.json({
                error: true,
                message: "connection failed",
                data: null
            })
        }
    }



});


app.post('/register', async (req, res) => {

    // console.log(req.body);
    const { name, email, password, role, test } = req.body

    if (!name || !email || !password || !role) {
        res.status(401).json({
            error: true,
            message: "Fill the form properly",
            data: null
        })

    } else {

        try {
            const data = await database.findOne({ email: email }).lean();
            console.log(data);
            const status = { hemo: false, thyr: false, glu: false }

            if (!data) {
                const newUser = new database({ name, email, password, role, test, status });
                newUser.save().then(async () => {
                    res.status(200).json({
                        error: false,
                        message: "Registrated Successfull",
                        data: null
                    })
                })
            } else {
                res.status(200).json({
                    error: true,
                    message: "user already Exist",
                    data: null
                })
            }


        } catch (err) {
            console.log(err);
            res.status(401).json({
                error: true,
                message: "Registrated failed",
                data: null
            })
        }
    }

});

app.use('/removeUser', async (req, res) => {

    const { id } = req.body;
    console.log(id)
    if (id) {
        await database.deleteOne({ _id: id })
        res.json({
            error: false,
            message: "user removed successfull",
            data: null
        })
    }


});


app.get('/sample', Authenticate, async (req, res) => {
    res.send(req.token);
});


app.get('/Entersample', Authenticate, async (req, res) => {
    // console.log('1111', req.body);
    res.send(req.token)
});


app.post('/Entersample', async (req, res) => {


    const { user, hemo, thyr, glu, date } = req.body
    console.log(user, hemo, thyr, glu, date);

    try {
        const status = { hemo, thyr, glu }
        await database.updateOne({ _id: user }, { $set: { test: true, date: date, status: status } })

        res.json({
            error: false,
            message: "data saves",
            date: null
        });

    } catch (err) {
        res.json({
            error: false,
            message: "data update failed",
            date: null
        });

        next(err)
    }
});


app.post('/heamatology', async (req, res) => {

    console.log(req.body)
    const { id, haemoglobin, neutrophils, eosinophiles, basophills, pcv, wbc, lymphocytes, monocytes, rbc, mcv } = req.body
    const heamatology = { haemoglobin, neutrophils, eosinophiles, basophills, pcv, wbc, lymphocytes, monocytes, rbc, mcv }
    await database.updateOne({ _id: id }, { $set: { heamatology: heamatology, test: true } });

    res.status(200).send({
        error: false,
        massage: " data saved",
        data: null
    });

});


app.post('/thyroid', async (req, res) => {

    console.log(req.body);
    const { id, tri, tsh, thyroxine } = req.body
    const thyroid = { tri, tsh, thyroxine }

    await database.updateOne({ _id: id }, { $set: { thyroid: thyroid, test: true } })

    res.json("data submited")
});


app.post('/glucometry', async (req, res) => {

    console.log(req.body);
    const { id, fbs, ppbs, gh, calcium } = req.body
    const glucometry = { fbs, ppbs, gh, calcium }
    await database.updateOne({ _id: id }, { $set: { glucometry: glucometry, test: true } })

    res.status(200).send({
        error: false,
        massage: " data saved",
        data: null
    });

});


app.listen(port, () => {
    console.log(`SERVER hosted at localhost:${port}`);
    // logger.log(`SERVER hosted at localhost:${port}`);
});